(() => {
  const state = {
    mode: "text",
    me: "m",
    look: "any",
    age: "18-21",
    topic: "talk",
    muted: false,
    timer: 0,
    timerId: null,
    searchId: null,
  };

  const greetings = {
    talk: [
      "Вечер. Можно просто поговорить — без спешки.",
      "Привет. Как ты сегодня, если коротко?",
      "На связи. О чём думаешь перед сном?",
    ],
    flirt: [
      "Привет. Голос в голове спокойный — надеюсь, и у тебя так.",
      "Раз уж нас свело — расскажи, какой у тебя вечер.",
    ],
    role: [
      "Можно медленно. Скажи, какой тон тебе сейчас ближе.",
      "Я здесь. Без спешки, с настроением.",
    ],
  };

  const replies = [
    "Понимаю.",
    "Звучит спокойно.",
    "Можно ещё чуть подробнее?",
    "Я тебя слышу.",
    "Да. Такие вечера редко бывают.",
    "Не торопись, я никуда не ухожу.",
    "Интересно. И что после этого?",
    "Тишина тоже разговор, если честно.",
  ];

  const $ = (id) => document.getElementById(id);
  const screens = [...document.querySelectorAll(".screen")];

  function show(name) {
    screens.forEach((s) => s.classList.toggle("active", s.id === `screen-${name}`));
    if (name !== "chat" && name !== "voice") stopTimer();
  }

  function selectIn(container, btn) {
    container.querySelectorAll(".pill, .choice").forEach((el) => el.classList.remove("selected"));
    btn.classList.add("selected");
  }

  document.querySelectorAll("[data-go]").forEach((btn) => {
    btn.addEventListener("click", () => show(btn.dataset.go));
  });

  $("btn-underage").addEventListener("click", () => show("denied"));

  document.querySelectorAll(".choice").forEach((btn) => {
    btn.addEventListener("click", () => {
      selectIn(btn.parentElement, btn);
      state.mode = btn.dataset.mode;
    });
  });

  document.querySelectorAll(".pills").forEach((group) => {
    group.querySelectorAll(".pill").forEach((btn) => {
      btn.addEventListener("click", () => {
        selectIn(group, btn);
        state[group.dataset.group] = btn.dataset.value;
      });
    });
  });

  $("btn-find").addEventListener("click", startSearch);
  $("btn-next-text").addEventListener("click", startSearch);
  $("btn-next-voice").addEventListener("click", startSearch);
  $("btn-end-text").addEventListener("click", endToHome);
  $("btn-end-voice").addEventListener("click", endToHome);

  $("btn-mute").addEventListener("click", () => {
    state.muted = !state.muted;
    $("wave").classList.toggle("muted", state.muted);
    $("mic-state").textContent = state.muted ? "микрофон выключен" : "микрофон включён";
  });

  $("composer").addEventListener("submit", (e) => {
    e.preventDefault();
    const input = $("msg-input");
    const text = input.value.trim();
    if (!text) return;
    addBubble(text, "out");
    input.value = "";
    window.setTimeout(() => {
      addBubble(replies[Math.floor(Math.random() * replies.length)], "in");
    }, 700 + Math.random() * 900);
  });

  function startSearch() {
    show("search");
    const copies = [
      "Тихий поиск. Никуда не торопимся.",
      "Ищем человека с похожим фильтром.",
      "Если пусто — ослабим возраст или пол.",
    ];
    $("search-copy").textContent = copies[Math.floor(Math.random() * copies.length)];
    clearTimeout(state.searchId);
    state.searchId = setTimeout(connect, 1600 + Math.random() * 1200);
  }

  function connect() {
    state.timer = 0;
    if (state.mode === "voice") {
      show("voice");
      state.muted = false;
      $("wave").classList.remove("muted");
      $("mic-state").textContent = "микрофон включён";
      startTimer($("voice-timer"));
      return;
    }
    show("chat");
    $("msgs").innerHTML = "";
    startTimer($("chat-timer"));
    const pool = greetings[state.topic] || greetings.talk;
    setTimeout(() => addBubble(pool[Math.floor(Math.random() * pool.length)], "in"), 400);
  }

  function addBubble(text, side) {
    const el = document.createElement("div");
    el.className = `bubble ${side}`;
    el.textContent = text;
    $("msgs").appendChild(el);
    $("msgs").scrollTop = $("msgs").scrollHeight;
  }

  function startTimer(node) {
    stopTimer();
    const tick = () => {
      const m = String(Math.floor(state.timer / 60)).padStart(2, "0");
      const s = String(state.timer % 60).padStart(2, "0");
      node.textContent = `${m}:${s}`;
      state.timer += 1;
    };
    tick();
    state.timerId = setInterval(tick, 1000);
  }

  function stopTimer() {
    if (state.timerId) clearInterval(state.timerId);
    state.timerId = null;
  }

  function endToHome() {
    stopTimer();
    show("home");
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
})();
